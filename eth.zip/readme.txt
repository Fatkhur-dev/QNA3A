tutorial menggunakan script:
1. Sebelum menjalankan script Masukkan username group yang tidak ingin di leave ke file group.txt
2. buka termux
3. install modul dg cara ketik dibawan ini:
   pip install telethon
   pip install requests
   pip install random
   pip install colorama   
4. buka script yg ada di penyimpanan device dg cara ketik dibawah ini:
   cd /sdcard/namafolderpenyimpananscript
   ls
5. kemudian jalankan script dg cara ketik dibawah ini
   python leave.py